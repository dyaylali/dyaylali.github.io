function [ rArray, vArray ] = GenerateEphemerides( JDArray, planet )
%GenerateEphemerides Generate array of planetary ephemerides
%   Requires Aerospace Toolbox and Ephemeris support package

   r_array = zeros(length(JDArray),3);
   v_array = zeros(length(JDArray),3);

   
   for i = 1:length(JDArray)
      [r_array(i,:), v_array(i,:)] = planetEphemeris(JDArray(i), 'Sun', planet,'421');
      % See documentation for planetEphemeris for more information on model choice.
      % Other methods: '405', '421', '423', '430', '432t'
   end

   rArray = r_array;
   vArray = v_array;

end

