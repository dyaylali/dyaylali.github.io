%{
FILENAME: Planetary_Constants.m

DESCRIPTION: This file creates structure arrays for the solar constants
and the mean planetary constants for epoch J2000.

MODIFICATIONS:
    15-Nov-2017   |   Aaron J. Rosengren - Original
    20-Nov-2017   |   David Yaylali - Simplified output

REFERENCES:
    Vallado, Fundamentals of Astrodynamics and Applications, 2007 
    (Appendix D.2-D.5 Planetary Constants)

%}

% -------------------------------------------------------------------------
%     MASS [ KG ]
% -------------------------------------------------------------------------
mass.sun = 1.9891e30;
mass.moon = 7.3483e22;
mass.mercury = 3.3022e23;
mass.venus = 4.869e24;
mass.earth = 5.9742e24;
mass.mars = 6.4191e23;
mass.jupiter = 1.8988e27;
mass.saturn = 5.685e26;
mass.uranus = 8.6625e25;
mass.neptune = 1.0278e26;
mass.pluto = 1.5e22;

% -------------------------------------------------------------------------
%     GRAVITATIONAL PARAMETER [ KM^3/S^2 ]
% -------------------------------------------------------------------------
mu.sun = 1.32712428e11;
mu.moon = 4902.799;
mu.mercury = 2.2032e4;
mu.venus = 3.257e5;
mu.earth = 3.986004415e5;
mu.mars = 4.305e4;
mu.jupiter = 1.268e8;
mu.saturn = 3.794e7;
mu.uranus = 5.794e6;
mu.neptune = 6.809e6;
mu.pluto = 9.00e2;

% -------------------------------------------------------------------------
%     SEMIMAJOR AXIS [ KM ]     
% -------------------------------------------------------------------------
a.sun = 149598023; 
a.moon = 384400;
a.mercury = 57909083;
a.venus = 108208601;
a.earth = 149598023;
a.mars = 227939186;
a.jupiter = 778298361;
a.saturn = 1429394133;
a.uranus = 2875038615;
a.neptune = 4504449769;
a.pluto = 5915799000;

% -------------------------------------------------------------------------
%     EQUATORIAL RADIUS [ KM ]
% -------------------------------------------------------------------------
R.sun = 696000;
R.moon = 1738;
R.mercury = 2439;
R.venus = 6052;
R.earth = 6378.1363;
R.mars = 3397.2;
R.jupiter = 71492;
R.saturn = 60238;
R.uranus = 25559;
R.neptune = 24764;
R.pluto = 1151;

   