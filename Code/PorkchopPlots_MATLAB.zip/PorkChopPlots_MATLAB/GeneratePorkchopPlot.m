%% Generate Porkchop Plots
% This script generates the "Porkchop plot" for interplanetary transfers 
% within the Solar System.
%
% Author: David Yaylali
% Date: November 2017
%
% Function Requirements:
%   lambertsolver.m
%
% Other Requirements:
%   Planetary_Constants.m
%
% Package Requirements:
%   This script requires the Aerospace Toolbox for MATLAB, along with the
%   JPL ephemeris dataset (add-on support package for the Aerospace 
%   Toolbox, found in the Add-On Explorer)
%
%~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

clearvars
close all
clc

% Import planetary constants and assign relevant parameters
run Planetary_Constants
muSun = mu.sun;
clear mu mass a R

% ------------- INPUTS ----------------------------------------------------
% Departure and arrival planets
depPlanet = 'Earth';
arrPlanet = 'Mars';

% Nominal departure and arrival times
JD_dep = juliandate(2005,6,20);
JD_arr = juliandate(2005,12,1);

% Define time window and grid resolution of the porkchop plot
tWindowDep = 140; %days past nominal departure
tWindowArr = 450; %days past nominal arrival
tStepDep = 2; % departure survey resolution
tStepArr = 5; % arrival survey resolution
% -------------------------------------------------------------------------



fprintf('\nGenerating the porkchop plot for trajectories \n')
fprintf('departing %s and arriving at %s.\n',depPlanet,arrPlanet)
depDate=datetime(JD_dep,'convertfrom','juliandate','Format','dd-MMM-yyy');
depStr=cellstr(depDate);
arrDate=datetime(JD_arr,'convertfrom','juliandate','Format','dd-MMM-yyy');
arrStr=cellstr(arrDate);
fprintf('Nominal departure date: %s \n',depStr{1})
fprintf('Nominal arrival date: %s \n \n', arrStr{1})


JDArrayDep = [JD_dep : tStepDep : JD_dep+tWindowDep];
JDArrayArr = [JD_arr : tStepArr : JD_arr+tWindowArr];

% Test to make sure all arival times are after departure times
if JDArrayDep(end) >= JDArrayArr(1);
    fprintf('\n*********************************************** \n');
    fprintf(' Error: Some arrival times before departure times! \n');
    fprintf('        Try adjusting arrival date and tWindow \n');
    fprintf('*********************************************** \n');
    return
end

% Generate array of planetary ephemerides at each departure/arrival time
% (these next two commands take a minute or two to complete)
tic
[rArray_dep, vArray_dep]=GenerateEphemerides(JDArrayDep, depPlanet);
[rArray_arr, vArray_arr]=GenerateEphemerides(JDArrayArr, arrPlanet);
tocVal = toc;
fprintf('\n Time to compute ephemeris array: %d s \n',tocVal)



% Now survey over all departure/arrival times, and use Lamberts algorithm
% to find needed delta-v's at departure and arrival
fprintf('\n Now building the porkchop plot... ')
for i = 1:length(JDArrayDep)

    JDi = JDArrayDep(i);

    for j = 1:length(JDArrayArr)

        JDf = JDArrayArr(j);
        
        %Build meshes for contour plot axis
        deltDepMesh(i,j) = JDi-JD_dep;
        deltArrMesh(i,j) = JDf-JD_arr;

        
        % Compute heliocentric orbital velocity at departure and arival
        % These are computed using Lambert's method
        TOF = 86400.0*(JDf - JDi); % time of flight, in seconds
        [v1Vec,v2Vec] = lambertsolver(muSun, rArray_dep(i,:), rArray_arr(j,:), TOF, 'pro');        

        % Compute v_inf for departure and arrival
        % (i.e., subtract planet velocities)
        vInf_dep = norm(v1Vec - vArray_dep(i,:)); 
        vInf_arr = norm(v2Vec - vArray_arr(j,:));

        % Compute porkchop plot values
        TOFarray(i,j) = JDf - JDi;
        C3(i,j) = vInf_dep^2;
        vInf(i,j) = vInf_arr;
    end
end
clear i j
fprintf('DONE!\n')

%% PLOT THE PORKCHOP
% Adjust the contour lines, colors as needed.

C3_levels = [15.5,16,17,18,20,22.5,30];
TOF_levels = [100, 150, 200, 250, 300, 350, 400, 450, 500];
V_inf_levels =  [3, 4, 5, 7, 8, 10];

col1=[0.8,0.2,0.2];
col2=[0.2,0.2,0.8];
col3 = [0.4,0.4,0.4];

close all
figure('position',[200,200, 800, 600])
set(gcf, 'color', 'w')
hold on
[c1,h1]=contour(deltDepMesh, deltArrMesh, vInf, V_inf_levels, 'color', col1,'linewidth',1.5);
[c2,h2]=contour(deltDepMesh, deltArrMesh, C3, C3_levels, 'color', col2,'linewidth',1.5);
[c3,h3]=contour(deltDepMesh, deltArrMesh, TOFarray, TOF_levels, 'color', col3);
hold off
% Comment out to turn off contour labels:
clabel(c1,h1,'Color',col1)
clabel(c2,h2,'Color',col2)
clabel(c3,h3,'Color',col3)
box on
xlabel(['Departure (Days past ', depStr{1},')'],'FontSize',18)
ylabel(['Departure (Days past ', arrStr{1},')'],'FontSize',18)
title([depPlanet, '-to-', arrPlanet, ' Trajectories'],'FontSize',18)
legend({'$v_{\infty}$','${\rm C}_3$','TOF'},'Location','northeastoutside','fontsize',16)


