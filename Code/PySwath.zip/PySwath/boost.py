#*********************
#
# Module that gives a general lorentz boost on a four-vector
#
#*********************

import math
import copy
import numpy as np
from fourvec import Fourvec
from fourvec import fourArray
from fourvec import fourVecFromArray


# Define the boost matrix

def makeBoostMatrix(betaVec):

    betaSq = betaVec[0]**2 + betaVec[1]**2 + betaVec[2]**2
    gamma = 1 / math.sqrt(1 - betaSq)

    boostMat = np.zeros((4, 4))
    boostMat[(0, 0)] = gamma

    boostMat[(0, 1)] = -gamma*betaVec[0]
    boostMat[(0, 2)] = -gamma*betaVec[1]
    boostMat[(0, 3)] = -gamma*betaVec[2]

    boostMat[(1, 0)] = -gamma*betaVec[0]
    boostMat[(2, 0)] = -gamma*betaVec[1]
    boostMat[(3, 0)] = -gamma*betaVec[2]

    boostMat[(1, 1)] = 1+((gamma-1)*betaVec[0]*betaVec[0])/betaSq
    boostMat[(1, 2)] = ((gamma-1)*betaVec[0]*betaVec[1])/betaSq
    boostMat[(1, 3)] = ((gamma-1)*betaVec[0]*betaVec[2])/betaSq


    boostMat[(2, 1)] = ((gamma-1)*betaVec[1]*betaVec[0])/betaSq
    boostMat[(2, 2)] = 1+((gamma-1)*betaVec[1]*betaVec[1])/betaSq
    boostMat[(2, 3)] = ((gamma-1)*betaVec[1]*betaVec[2])/betaSq


    boostMat[(3, 1)] = ((gamma-1)*betaVec[2]*betaVec[0])/betaSq
    boostMat[(3, 2)] = ((gamma-1)*betaVec[2]*betaVec[1])/betaSq
    boostMat[(3, 3)] = 1+((gamma-1)*betaVec[2]*betaVec[2])/betaSq

    return boostMat

#----------------------------------------------------


# Define the boosted four vectors (as defined as the Fourvec Class in fourvec.py)

def boostedVec(initFourvec, betaVecB):
    
    boostMat = makeBoostMatrix(betaVecB)
    finFourArray = np.dot(boostMat, fourArray(initFourvec))
    finThreevec = [finFourArray[1], finFourArray[2], finFourArray[3]]
    finFourvec = copy.copy(initFourvec)   ### Original four vector is not over written.  
    finFourvec.assn_p_cart(finThreevec)
    return finFourvec


# Define the boosted four vectors as a numpy array.

def boostedArray(initFourvec, betaVecB):
    
    boostMat = makeBoostMatrix(betaVecB)
    finFourArray = np.dot(boostMat, fourArray(initFourvec))
    return finFourArray

# Translate from spherical FourVec to cartesian FourVec

