def writeLHE(mg5RunData, pyRun):

##############################
##
## INITIALIZE LHE OUTPUT FILE
##
##############################

    mPhi = pyRun['mPhi']
    print(mPhiVal)

#
# outfilestr = "Events_mPhi" + str(int(mPhi)) + "_m0" + str(int(m0)) + "_delm" + str(int(delm))+ "_d" + str(int(delta))+ "_g" + str(int(gamma)) + ".lhe"
# outfile = open(outfilestr, 'w')
#
# ## WRITE HEADER
# outfile.write('<LesHouchesEvents version="3.0">\n')
# outfile.write('<header> \n')
# outfile.write('<!-- \n')
# outfile.write('Number of Events: ' + str(nEvents) + '\n')
# outfile.write('mPhi = ' + str(mPhi) + '\n')
# outfile.write('m0 = ' + str(m0) + '\n')
# outfile.write('delta m = ' + str(delm) + '\n')
# outfile.write('delta = ' + str(delta) + '\n')
# outfile.write('gamma = ' + str(gamma) + '\n')
# outfile.write('Number of states above ground = ' + str(nX) + '\n')
# outfile.write('--> \n')
#
# outfile.write('<slha> \n \n')
# outfile.write('###################################\n')
# outfile.write('## INFORMATION FOR MASS \n')
# outfile.write('###################################\n')
# outfile.write('Block mass  \n \n')
#
# pdgPhiStr = '{:>9}'.format(str(pdgPhi))
# mPhistr = '{:>12}'.format(str('%.6E' % Decimal(mPhi)))
#
# paticleMassBlock = {i: '{:>9}'.format(str(pdgX[i])) + ' ' + '{:>12}'.format(str('%.6E' % Decimal(mX[i]))) + '  # MX' + str(i) for i in range(nX+1)}
#
#
#
# outfile.write(pdgPhiStr+ ' ' + mPhistr + '  # MPhi \n')
# for i in range(nX + 1):
#     outfile.write(paticleMassBlock[i]+'\n')
#
# outfile.write('\n\n###################################\n')
# outfile.write('## INFORMATION FOR DECAY \n')
# outfile.write('###################################\n\n')
# outfile.write('Block QNUMBERS 9000010  # phix \n')
# outfile.write('        1 -1  # 3 times electric charge \n')
# outfile.write('        2 1  # number of spin states (2S+1) \n')
# outfile.write('        3 3  # colour rep (1: singlet, 3: triplet, 8: octet) \n')
# outfile.write('        4 1  # Particle/Antiparticle distinction (0=own anti) \n')
#
# for i in range(nX+1):
#     outfile.write('Block QNUMBERS ' + str(pdgX[i]) +'  # X' + str(i) +' \n')
#     outfile.write('        1 0  #  \n')
#     outfile.write('        2 2  #  \n')
#     outfile.write('        3 1  #  \n')
#     outfile.write('        4 1  #  \n')
#
#
# outfile.write('\n \n')
# outfile.write('#*************************\n')
# outfile.write('#      Decay widths      *\n')
# outfile.write('#*************************\n \n')
# outfile.write('#      PDG        Width \n')
# outfile.write('DECAY  9000010   ' + '{:>12}'.format(str('%.6E' % Decimal(totWidPhi))) + '\n')
#
#
#
# outfile.write('#  BR             NDA  ID1    ID2   ... \n')
# for i in range(nX+1):
#     outfile.write('{:>15}'.format(str('%.6E' % Decimal(brPhi[i]))) +'   2    1  -'+ str(pdgX[i]) +'\n')
#
#
# outfile.write('#\n#      PDG        Width \n')
# outfile.write('DECAY  9000011   0.000000e+00 \n')
#
#
# for i in range(1,nX+1):
#     outfile.write('#\n#      PDG        Width \n')
#     outfile.write('DECAY  ' + '{:<10}'.format(str(pdgX[i]))    + '{:>12}'.format(str('%.6E' % Decimal(totWidPhi))) + '\n')
#     outfile.write('#  BR             NDA  ID1    ID2   ... \n')
#     for j in range(i):
#         outfile.write('{:>15}'.format(str('%.6E' % Decimal(brX[i][j]))) + '   3    -1  1  '+ str(pdgX[j])+'\n')
#
# #DECAY  9000012   5.529100e-10
#
#
#
#
#
# print 'Width of x1: ', widthX[1][0]
#
#
# outfile.write('\n \n \n')
# outfile.write('</slha> \n')
#
# outfile.write('</header> \n')
#
#
#
#
#
#
# outfile.write('<init> \n')
# ##NOT SURE IF INITIALIZATION DATA IS NEEDED IN LHE FILE, BUT INCLUDE IT ANYWAYS
# MG5fnameString = './PhiProductionData/PhiProduction_mPhi_' + str(int(mPhi)) + '.lhe'
# with open(MG5fnameString) as fp:
#     for i, line in enumerate(fp):
#         if '<init>' in line:
#            runInitLine1 =  fp.next().split()
#            runInitLine2 =  fp.next().split()
#            runB1Energy = runInitLine1[2]
#            runB2Energy = runInitLine1[3]
#            PDFGUP1 = runInitLine1[4]
#            PDFGUP2 = runInitLine1[5]
#            PDFSUP1 = runInitLine1[6]
#            PDFSUP2 = runInitLine1[7]
#            IDWTUP = runInitLine1[8]
#            NPRUP = runInitLine1[9]
#            xsec = runInitLine2[0]
#            xsecEr = runInitLine2[1]
#            xsecMax = runInitLine2[2]
#            xsecLab = runInitLine2[3]
#         if '</init>' in line:
#             break
#
#
# outfile.write('     2212     2212  '+ runB1Energy + '  ' + runB2Energy + ' ' + PDFGUP1 + ' ' + PDFGUP2 + ' ' + PDFSUP1 + ' ' + PDFSUP2 + '  ' + IDWTUP + '   ' + NPRUP + '\n')
# outfile.write('  '+ xsec + '  ' + xsecEr + '  ' + xsecMax + '  ' + xsecLab+ '\n')
#
# outfile.write('</init> \n')
