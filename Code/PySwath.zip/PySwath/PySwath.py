#! /usr/bin/env python

import math
import numpy as np
import random
import fourvec
from fourvec import Fourvec
from boost import boostedArray
import time
import os
from scipy.stats import rv_continuous
import scipy
from decimal import Decimal
from itertools import islice
import sys
import mg5data
import decayKinematics

PI = math.pi
DEGRAD = 180.0/math.pi

print
print '########### This is PySwath, a MC Event Generator ######################'
print '#   Writen by David Yaylali --- david.yaylali@gmail.com'
print '#   Updated: Feb 25, 2019 '
print '#'
print '#   This code decays phi-phibar events from proton-proton collisions.'
print '#     Input: '
print '#       Production events in LHE format must exist in the directory'
print '#       ./PhiProductionData'
print '#     Output: '
print '#       Event records will be recorded in standard LHE format for '
print '#       hadronization and detector simulation'
print '#'
print '#   See arXiv:###### for more information'
print '#'
print '########################################################################'

############################
# RUN AND MODEL PARAMETERS
############################
nEvents = 1000

#Warning: avoid using fractions... write as floating point instead: 1/2 -> 0.5
mPi = 0.33  ## Needs to be 0.33 (mq ~ 1/3 mProton) in order to be processed by Pythia
m0 = 100.0
delm = 10.0
mPhi = 1000.0 # NOTE: If this is changed, new production phi-phibar production data needs to be generated in MadGraph
c0 = 0.1
delta = 1
gamma = 1
nX = int(math.floor(((mPhi - mPi - m0) / delm)**(1./delta)))    # Index of maximum state X_i
                                                                # aka: Number of (accesible) states in tower above ground.

##############
# DEFINITIONS
##############
pdgPhi = 9000010
pdgJet = 1  #Assume all jets are down quarks

################################
# Check for mg5 generated events
################################

eventsGenerated = True
MG5fnameString = './PhiProductionData/PhiProduction_mPhi_' + str(int(mPhi)) + '.lhe'
if not os.path.isfile(MG5fnameString):
   print "LHE file for this value of mPhi does not exist.  Run MadGraph5 to generate Phi momenta"
   eventsGenerated = False

if eventsGenerated == False:
   sys.exit(0)


with open(MG5fnameString) as fp:
   content = fp.read()
   eventsStart = content.index('<event>')


#----------------------------------------------
# GENERATE ARRAYS OF PARTICLES AND COUPLINGS
#----------------------------------------------

##List of X PDG codes
pdgX = [ 9000011 + (i) for i in range(nX+1) ]
##List of masses
mX = [ m0 + (i**delta)*delm for i in range(nX+1) ]
##List of couplings
cX = [ c0*((1.0+mX[i])/m0)**gamma for i in range(nX+1) ]

##Dictionaries for particle momentum data strings (for data output)
pXstr = {0 : ''}
pJ1str = {0 : ''}
pJ1Barstr = {0 : ''}

pXBarstr = {0 : ''}
pJ2str = {0 : ''}
pJ2Barstr = {0 : ''}


class Xparticle:
  def __init__(self, pdg, mass, cx):
    self.pdg = pdg
    self.mass = mass
    self.cx = cx
# Note: this class is not used in this version

print
print 'MODEL PARAMETERS FOR THIS RUN:'
print 'Mass of Phi: ', mPhi
print 'Mass of X[0]: ', m0
print 'Mass difference Delta_m: ', delm
print 'Mass scaling paramter delta: ', delta
print 'Coupling scaling parameter gamma: ', gamma
print 'Base coupling c0: ', c0
print 'Highest-mass state: X[{}]'.format(nX)
print
print 'Number of events to be generated: ', nEvents
print
print 'BEGINNING EVENT GENERATION...'




#---------------------------------------------------------------------------
# GENERATE DECAY WIDTHS, BRANCHING FRACTIONS, AND PROBABILITY DISTRIBUTIONS
#---------------------------------------------------------------------------

# indPhi represents the index i of X[i] to which the phi decays to...
# So brPhi[7] is the branching fraction of phi to X[7]
indPhi = [x for x in range(nX + 1)]
indPhiBar = [x for x in range(nX + 1)]

widthPhi = np.array([(cX[x]**2)*(( (mPhi)**2 - (mX[x])**2 )**2)/(16*PI*(mPhi**3)) for x in range(nX + 1)])
brPhi = np.array([widthPhi[x]/sum(widthPhi) for x in range(nX + 1)])
totWidPhi = sum(widthPhi)

# Dictionary for branching fractions for Xi
# So brX[i][j] is the branching fraction for Xi to Xj
# Indices i run from 0 to nX
# Index j, given by indX, runs from 0 to i - 1.
indX = {y: [x for x in range(y)] for y in range(1, nX + 1)}
indXbar = {y: [x for x in range(y)] for y in range(1, nX + 1)}

f1 = {n: np.array([
            (6*(mX[n]**2 - mX[m]**2) / mPhi**2) - (5*(mX[n]**4 - mX[m]**4)/(mPhi**4)) + ((2*(mX[n]**2)*(mX[m]**2)*(mX[n]**2 - mX[m]**2))/(mPhi**6))
            for m in range(n)]) for n in range(1, nX + 1)}
f2 = {n: np.array([
            6 - ((8*(mX[n]**2 + mX[m]**2))/(mPhi**2)) + ((2*(mX[n]**4 + 4*(mX[n]**2)*(mX[m]**2) + mX[m]**4)/(mPhi**4)) - ((2*(mX[n]**4)*(mX[m]**4))/(mPhi**8)))
            for m in range(n)]) for n in range(1, nX + 1)}
f3 = {n: np.array([ (2*(mX[n]**4)*(mX[m]**4))/(mPhi**8) for m in range(n)]) for n in range(1, nX + 1)}

# GENERAL BRANCHINGS
widthX = {n: np.array([(scipy.integrate.quad( lambda m23SqPar: ((3*cX[n]**2 * cX[m]**2) * ((mX[n]**2 - m23SqPar)**2 * (m23SqPar - mX[m]**2)**2) / (512 * PI**3 * mX[n]**3 * m23SqPar * (mPhi**2 - m23SqPar)**2) ) , mX[m]**2, mX[n]**2)[0]) for m in range(n)]) for n in range(1, nX + 1)}
brX = {n: np.array([ (widthX[n][x])/sum(widthX[n]) for x in range(n)]) for n in range(1, nX + 1)}

# FORM PROPABILITY DISTRIBUTIONS
class m23Sq_pdf(rv_continuous):
    def _pdf(self, m23Sq, n, m):
        return ((3*cX[n-1]**2 * cX[m-1]**2) * ((mX[n-1]**2 - m23Sq)**2 * (m23Sq - mX[m-1]**2)**2) / (512 * PI**3 * mX[n-1]**3 * m23Sq * (mPhi**2 - m23Sq)**2 * (widthX[n-1][m-1]) )  )

m23Dic = {n: np.array([m23Sq_pdf(a=mX[m]**2, b=mX[n]**2) for m in range(n)]) for n in range(1, nX + 1)}
m23Dist = {p: np.array([m23Dic[p][q](n=p + 1, m=q + 1) for q in range(p)]) for p in range(1, nX + 1)}
# m23Vals = {p: np.array([m23Dist[p][q].rvs(size = 10) for q in range(p)]) for p in range(1, nX + 1)}

def m23Sample(m, n):
    m23SqSampled = m23Dist[n][m].rvs()
    return m23SqSampled


# Store all run data for later use (this is sloppy, but it works fine for our purposes)
runData = [mPi, m0, delm, mPhi, c0, delta, gamma, nX, pdgPhi, pdgJet, pdgX, mX, cX, totWidPhi, brPhi, nEvents, widthX, brX]

#------------------------------------
# INITIALIZE THE OUTPUT LHE FILE
#------------------------------------

import writeLHEfile
writeLHEfile.initializeLHE(runData)
#Open LHE file for recording events
outfilestr = "Events_mPhi" + str(int(mPhi)) + "_m0" + str(int(m0)) + "_delm" + str(int(delm))+ "_d" + str(int(delta))+ "_g" + str(int(gamma)) + ".lhe"
outfile = open(outfilestr, 'a')

#------------------------------------
# INITIALIZE SOME HISTOGRAMS
#------------------------------------

nJetBins = 100
pTBins = 5000
histoJetSize = np.zeros(nJetBins)
histoJetPT = np.zeros(pTBins)



################################################
#------ BEGINNING OF EVENT LOOP ----------------
################################################
# Warning: All print statements within the loop are for diagnostic purposes and
# should only be uncommented if nEvents is small (<100).

start = time.clock() ##For timing purposes

for evNum in xrange(0, nEvents):

    nparticles = 2; #number of particles in event (for LHE file.. start with two gluons)

    if (evNum % 100 == 0): print evNum, "events generated..." # display loop progress

    #dictionary for fourmomentum
    #...of Phi
    pPhi = Fourvec(mPhi, 'rest', [0.0,0.0,0.0], 'polar')
    #print 'Four vector, Phi: ', fourvec.fourArray(pPhi)

    #...of PhiBar
    pPhiBar = Fourvec(mPhi, 'rest', [0.0,0.0,0.0], 'polar')
    #print 'Four vector, Phi: ', fourvec.fourArray(pPhi)

    #...of Xs
    pX = {x: Fourvec(mX[x], 'rest', [0.0, 0.0, 0.0], 'polar') for x in range(nX + 1)}
    pXBar = {x: Fourvec(mX[x], 'rest', [0.0, 0.0, 0.0], 'polar') for x in range(nX + 1)}

    #print 'Four vector, X: ', fourvec.fourArray(pX[8])

    #...of jets (associated with each X)
    # If Xi decays to X6, it produces the jet pJ[6]
    # Jets associated with the PhiBar leg are labeled with 1, Phi leg with 2
    pJ1 = {x: Fourvec(mPi, 'total', [0.0, 0.0, 0.0], 'polar') for x in range(nX + 1)} # Using pion mass for jet, due to confinement
    pJ1Bar = {x: Fourvec(mPi, 'total', [0.0, 0.0, 0.0], 'polar') for x in range(nX + 1)}
    pJ2 = {x: Fourvec(mPi, 'total', [0.0, 0.0, 0.0], 'polar') for x in range(nX + 1)}
    pJ2Bar = {x: Fourvec(mPi, 'total', [0.0, 0.0, 0.0], 'polar') for x in range(nX + 1)}
    #----------------------------------


    # Initialize jet counter for the event.
    totJetCount = 0
    jet1Count = 0
    jet2Count = 0

    ############################################################################
    #--------------- Generate Kinematics for Event -----------------------------
    ############################################################################

    # GET PARTICLE DATA FROM MADGRAPH

    phidata, phibardata, glue1data, glue2data, eventdata = mg5data.getParticleData(evNum, mPhi, eventsStart)
    pPhix = phidata[0]
    pPhiy = phidata[1]
    pPhiz = phidata[2]
    pPhiBarx = phibardata[0]
    pPhiBary = phibardata[1]
    pPhiBarz = phibardata[2]

    #Assign Momenta of Phi Particles
    pPhi.assn_p_cart([pPhix, pPhiy, pPhiz])
    betaPhi = decayKinematics.betaVec(pPhi)
    pPhiBar.assn_p_cart([pPhiBarx, pPhiBary, pPhiBarz])
    betaPhiBar = decayKinematics.betaVec(pPhiBar)

    nparticles += 2 #increase particle counter

    #-----------------PHIBar LEG OF EVENT GENERATION----------------------
    #### DECAY THE PHIBar ####
    # Decay to random member Xi using random angles in CM frame
    decayIndx = np.random.choice(indPhi, 1, p=brPhi)[0]
    u = random.uniform(-1, 1)
    thetaX = math.acos(u)
    phiX = random.uniform(0, 2*PI)
    #...and reassign the four vectors based on this Xi mass and these angles.
    # These are momenta in the rest frame of the phi.
    pXvec = [((mPhi**2 - mX[decayIndx]**2)/(2.0*mPhi)), thetaX, phiX]
    pJ1Barvec = [-((mPhi**2 - mX[decayIndx]**2)/(2.0*mPhi)), thetaX, phiX]
    #Assign X and J particles
    pX[decayIndx].assn_p_pola(pXvec)
    nparticles += 1
    pJ1Bar[decayIndx].assn_p_pola(pJ1Barvec)
    nparticles += 1
    # Jet assigned, so we increment jetCount
    jet1Count += 1

    #### NOW BOOST TO LAB FRAME, SINCE PHI WAS BOOSTED ####
    pXinitBoosted = boostedArray(pX[decayIndx], betaPhiBar)
    pX[decayIndx].assn_p_cart([pXinitBoosted[1], pXinitBoosted[2], pXinitBoosted[3]])
    pJ1BarinitBoosted = boostedArray(pJ1Bar[decayIndx], betaPhiBar)
    pJ1Bar[decayIndx].assn_p_cart([pJ1BarinitBoosted[1], pJ1BarinitBoosted[2], pJ1BarinitBoosted[3]])

    #------ GENERATE THE X DECAY CHAIN--------
    # Now we want to decay the X[i] chosen above to X[j] plus two jets.
    motherIndx = decayIndx
    colIdx = 503
    xDecCount = 0

    while motherIndx > 0:
    #First, decay the X[i] in it's rest frame:
        daughterIndx = np.random.choice(indX[motherIndx], 1, p=brX[motherIndx])[0]

        m23SqSampled = m23Sample(daughterIndx, motherIndx)
        # Note, in what follows, particle 1 is the J1, particle 2 is the X, and particle 3 is the J1Bar
        E1 = (mX[motherIndx]**2 - m23SqSampled) / (2*mX[motherIndx])  # Energy of the J1 (as opposed to J1Bar)
        # Now select m12Sq (E3)... this is a uniformly distributed value between m12Sqmin and m12Sqmax
        m12Sqmin = mX[motherIndx]**2 * mX[daughterIndx]**2 / m23SqSampled
        m12Sqmax = mX[motherIndx]**2 + mX[daughterIndx]**2 - m23SqSampled
        m12SqSampled = random.uniform(m12Sqmin, m12Sqmax)

        E3 = (mX[motherIndx]**2 - m12SqSampled) / (2*mX[motherIndx]) # Energy of the J1Bar

        p2 = math.sqrt((E1+E3)**2 - 2*mX[motherIndx]*(E1+E3) + mX[motherIndx]**2 - mX[daughterIndx]**2)
        cosTh = (E3**2 - E1**2 - p2**2) / (2*p2*E1)

        pXvec = [0, 0, p2]
        pJ1vec = [0, E1*math.sin(math.acos(cosTh)), E1*cosTh]
        pJ1Barvec = [0, -E1*math.sin(math.acos(cosTh)), -1*(p2+E1*cosTh)]

        #Now rotate entire system by random angle...
        M = decayKinematics.rand_rotation_matrix()
        pXvecPrime = M.dot(pXvec)
        pJ1vecPrime = M.dot(pJ1vec)
        pJ1BarvecPrime = M.dot(pJ1Barvec)

        # Assign daugter X and j jbar
        pX[daughterIndx].assn_p_cart(pXvecPrime)
        pJ1[daughterIndx].assn_p_cart(pJ1vecPrime)
        pJ1Bar[daughterIndx].assn_p_cart(pJ1BarvecPrime)
        nparticles += 3

        # 2 Jets assigned, so we increment jetCount
        jet1Count += 2

        #Calculate beta vector of mother in order to boost daughters
        betaMother = decayKinematics.betaVec(pX[motherIndx])

        # Boost X and j to the lab frame...
        pXboosted = boostedArray(pX[daughterIndx], betaMother)
        pJ1boosted = boostedArray(pJ1[daughterIndx], betaMother)
        pJ1Barboosted = boostedArray(pJ1Bar[daughterIndx], betaMother)

        # Now redefine the fourvectors... now these are in the lab frame.
        pX[daughterIndx].assn_p_cart([pXboosted[1], pXboosted[2], pXboosted[3]])
        pJ1[daughterIndx].assn_p_cart([pJ1boosted[1], pJ1boosted[2], pJ1boosted[3]])
        pJ1Bar[daughterIndx].assn_p_cart([pJ1Barboosted[1], pJ1Barboosted[2], pJ1Barboosted[3]])

        # Make LHE file strings
        colIdx += 1
        xDecCount += 1
        if daughterIndx == 0:
            partStat = 1
        else:
            partStat = 2
        pXstr.update({xDecCount : writeLHEfile.lhefString(pdgX[daughterIndx],partStat,7+(xDecCount-1)*3,0,0,0,pX[daughterIndx].px, pX[daughterIndx].py, pX[daughterIndx].pz, pX[daughterIndx].E, pX[daughterIndx].m0())} )
        pJ1str.update({xDecCount : writeLHEfile.lhefString(1,1,7+(xDecCount-1)*3,0,colIdx,0,pJ1[daughterIndx].px, pJ1[daughterIndx].py, pJ1[daughterIndx].pz, pJ1[daughterIndx].E, pJ1[daughterIndx].m0())})
        pJ1Barstr.update({xDecCount : writeLHEfile.lhefString(-1,1,7+(xDecCount-1)*3,0,0,colIdx,pJ1Bar[daughterIndx].px, pJ1Bar[daughterIndx].py, pJ1Bar[daughterIndx].pz, pJ1Bar[daughterIndx].E, pJ1Bar[daughterIndx].m0())})

        # Now set this daughter (now expressed in lab frame) to be the mother
        motherIndx = daughterIndx
    #-------------END OF PHIBar LEG OF EVENT GENERATION-------------------

    #-----------------PHI LEG OF EVENT GENERATION----------------------

    #### DECAY THE PHI ####
    # Decay to random member Xi using random angles in CM frame
    decayBarIndx = np.random.choice(indPhiBar, 1, p=brPhi)[0]
    u = random.uniform(-1, 1)
    thetaX = math.acos(u)
    phiX = random.uniform(0, 2*PI)
    #...and reassign the four vectors based on this Xi mass and these angles.
    # These are momenta in the rest frame of the phi.
    pXBarvec = [((mPhi**2 - mX[decayBarIndx]**2)/(2.0*mPhi)), thetaX, phiX]
    pJ2vec = [-((mPhi**2 - mX[decayBarIndx]**2)/(2.0*mPhi)), thetaX, phiX]
    #Assign Xbar and J
    pXBar[decayBarIndx].assn_p_pola(pXBarvec)
    pJ2[decayBarIndx].assn_p_pola(pJ2vec)
    nparticles += 2
    # Jet assigned, so we increment jetCount
    jet2Count += 1

    #### NOW BOOST TO LAB FRAME, SINCE PHI WAS BOOSTED ####
    pXBarinitBoosted = boostedArray(pXBar[decayBarIndx], betaPhi)
    pXBar[decayBarIndx].assn_p_cart([pXBarinitBoosted[1], pXBarinitBoosted[2], pXBarinitBoosted[3]])
    pJ2initBoosted = boostedArray(pJ2[decayBarIndx], betaPhi)
    pJ2[decayBarIndx].assn_p_cart([pJ2initBoosted[1], pJ2initBoosted[2], pJ2initBoosted[3]])

    #------ GENERATE THE XBar DECAY CHAIN--------
    # Now we want to decay the X[i] chosen above to X[j] plus two jets.
    motherIndx = decayBarIndx
    # colIdx = 503
    xbarDecCount = 0

    while motherIndx > 0:
    #First, decay the X[i] in it's rest frame:
        # print "Phi Decay:"
        daughterIndx = np.random.choice(indXbar[motherIndx], 1, p=brX[motherIndx])[0]

        m23SqSampled = m23Sample(daughterIndx, motherIndx)
        # Note, in what follows, particle 1 is the J2Bar, particle 2 is the XBar, and particle 3 is the J2
        E1 = (mX[motherIndx]**2 - m23SqSampled) / (2*mX[motherIndx]) # Energy of the J2Bar

        m12Sqmin = mX[motherIndx]**2 * mX[daughterIndx]**2 / m23SqSampled
        m12Sqmax = mX[motherIndx]**2 + mX[daughterIndx]**2 - m23SqSampled
        m12SqSampled = random.uniform(m12Sqmin, m12Sqmax)

        E3 = (mX[motherIndx]**2 - m12SqSampled) / (2*mX[motherIndx]) # Energy of the J2
        # print "E3=", E3

        p2 = math.sqrt((E1+E3)**2 - 2*mX[motherIndx]*(E1+E3) + mX[motherIndx]**2 - mX[daughterIndx]**2)
        cosTh = (E3**2 - E1**2 - p2**2) / (2*p2*E1)

        pXBarvec = [0, 0, p2]
        pJ2Barvec = [0, E1*math.sin(math.acos(cosTh)), E1*cosTh]
        pJ2vec = [0, -E1*math.sin(math.acos(cosTh)), -1*(p2+E1*cosTh)]

        #Now rotate entire system by random angle...
        M = decayKinematics.rand_rotation_matrix()
        pXBarvecPrime = M.dot(pXBarvec)
        pJ2BarvecPrime = M.dot(pJ2Barvec)
        pJ2vecPrime = M.dot(pJ2vec)

        # Define the daughter X and j fourvectors in the rest frame of their mother...
        pXBar[daughterIndx].assn_p_cart(pXBarvecPrime)
        pJ2Bar[daughterIndx].assn_p_cart(pJ2BarvecPrime)
        pJ2[daughterIndx].assn_p_cart(pJ2vecPrime)
        nparticles += 3

        # 2 Jets assigned, so we increment jetCount
        jet2Count += 2

        #Calculate beta vector of mother in order to boost daughter
        betaMother = decayKinematics.betaVec(pXBar[motherIndx])

        # Boost X and j to the lab frame...
        pXBarboosted = boostedArray(pXBar[daughterIndx], betaMother)
        pJ2boosted = boostedArray(pJ2[daughterIndx], betaMother)
        pJ2Barboosted = boostedArray(pJ2Bar[daughterIndx], betaMother)

        # Now redefine the fourvectors... now these are in the lab frame.
        pXBar[daughterIndx].assn_p_cart([pXBarboosted[1], pXBarboosted[2], pXBarboosted[3]])
        pJ2[daughterIndx].assn_p_cart([pJ2boosted[1], pJ2boosted[2], pJ2boosted[3]])
        pJ2Bar[daughterIndx].assn_p_cart([pJ2Barboosted[1], pJ2Barboosted[2], pJ2Barboosted[3]])

        # Make LHE file strings
        colIdx += 1
        xbarDecCount += 1
        if daughterIndx == 0:
            partStat = 1
        else:
            partStat = 2
        pXBarstr.update({xbarDecCount : writeLHEfile.lhefString(-pdgX[daughterIndx],partStat,8+(xDecCount)*3+(xbarDecCount-1)*3,0,0,0,pXBar[daughterIndx].px, pXBar[daughterIndx].py, pXBar[daughterIndx].pz, pXBar[daughterIndx].E, pXBar[daughterIndx].m0())} )
        pJ2str.update({xbarDecCount : writeLHEfile.lhefString(1,1,8+(xDecCount)*3+(xbarDecCount-1)*3,0,colIdx,0,pJ2[daughterIndx].px, pJ2[daughterIndx].py, pJ2[daughterIndx].pz, pJ2[daughterIndx].E, pJ2[daughterIndx].m0())})
        pJ2Barstr.update({xbarDecCount : writeLHEfile.lhefString(-1,1,8+(xDecCount)*3+(xbarDecCount-1)*3,0,0,colIdx,pJ2Bar[daughterIndx].px, pJ2Bar[daughterIndx].py, pJ2Bar[daughterIndx].pz, pJ2Bar[daughterIndx].E, pJ2Bar[daughterIndx].m0())})



        # Now set this daughter (now expressed in lab frame) to be the mother
        motherIndx = daughterIndx
    #-------------END OF PHI LEG OF EVENT GENERATION-------------------

    ############################################################################
    #-------------- End of Event Kinematics Generation -------------------------
    ############################################################################


    #---- Now Analyze the event and store in LHEF---------

    #### JET SORTING ####
    #Sort J1 jets by pT
    dtype = [('index', int), ('pT', float)]
    jList = [(x, fourvec.pTrans(pJ1[x])) for x in xrange(nX)]
    a = np.array(jList, dtype=dtype)
    jListSorted = np.sort(a, order='pT')
    # Sort in decreasing order
    jListSorted = jListSorted[::-1]
    J1List = jListSorted
    dtype = [('index', int), ('pT', float)]

    #COMBINE ALL JETS into pT ordered list
    pJet = {x: pJ1[x] for x in xrange(nX+1)}
    pJet.update({x+nX+1: pJ1Bar[x] for x in xrange(nX + 1)})
    pJet.update({x+2*nX+2: pJ2[x] for x in xrange(nX + 1)})
    pJet.update({x+3*nX+3: pJ2Bar[x] for x in xrange(nX + 1)})
    jList = [(x, fourvec.pTrans(pJet[x])) for x in xrange(4*nX + 4)]
    b = np.array(jList, dtype=dtype)
    jListSorted = np.sort(b, order='pT')
    jListSorted = jListSorted[::-1]
    JetList = jListSorted
    # Now, JetList[i][j] stores the pTs of the jets.  Index i is the ith biggest pT jet, index j records either the Xi index (0) or the pT (1).
    # So, JetList[0][1] gives the leading pT jet in the event.


    #### Fill Histograms ####
    # Jet number
    totJetCount = jet1Count + jet2Count
    histoJetSize[totJetCount] += 1
    # Leading jet pT
    histoJetPT[int(math.floor(JetList[0][1]))] += 1


    #phidata = [pPhix, pPhiy, pPhiz, phiColA, phiColB]

    #------ WRITE FULL EVENT TO LHE FILE ---------------------------------------
    outfile.write('<event>\n')
    outfile.write(str(nparticles) + '\t' + '1' + '\t' + eventdata[0] + '\t' + eventdata[1] + '\t' + eventdata[2] + '\t' + eventdata[3] + '\n')
    outfile.write(writeLHEfile.lhefString(glue1data[1], -1, 0, 0, glue1data[2], glue1data[3], 0, 0, glue1data[0], abs(glue1data[0]), 0))
    outfile.write(writeLHEfile.lhefString(glue2data[1], -1, 0, 0, glue2data[3], glue2data[3], 0, 0, glue2data[0], abs(glue2data[0]), 0))
    outfile.write(writeLHEfile.lhefString(pdgPhi, 2, 1, 2, phidata[3], phidata[4], pPhi.px, pPhi.py, pPhi.pz, pPhi.E, pPhi.m0()))
    outfile.write(writeLHEfile.lhefString(-pdgPhi, 2, 1, 2, phibardata[3], phibardata[4], pPhiBar.px, pPhiBar.py, pPhiBar.pz, pPhiBar.E, pPhiBar.m0()))
    outfile.write(writeLHEfile.lhefString(-1, 1, 4, 0, phibardata[3], phibardata[4], pJ1Bar[decayIndx].px, pJ1Bar[decayIndx].py, pJ1Bar[decayIndx].pz, pJ1Bar[decayIndx].E, pJ1Bar[decayIndx].m0()))
    outfile.write(writeLHEfile.lhefString(1, 1, 3, 0, phidata[3], phidata[4], pJ2[decayBarIndx].px, pJ2[decayBarIndx].py, pJ2[decayBarIndx].pz, pJ2[decayBarIndx].E, pJ2[decayBarIndx].m0()))
    #Initial X
    if decayIndx == 0:
        partStat = '1'
    else:
        partStat = '2'
    outfile.write(writeLHEfile.lhefString(pdgX[decayIndx],partStat,4,0,0,0,pX[decayIndx].px, pX[decayIndx].py, pX[decayIndx].pz, pX[decayIndx].E, pX[decayIndx].m0()))
    for i in range(1,xDecCount+1):
        outfile.write(pJ1str[i])
        outfile.write(pJ1Barstr[i])
        outfile.write(pXstr[i])
    #Initial Xbar
    if decayBarIndx == 0:
        partStat = '1'
    else:
        partStat = '2'
    outfile.write(writeLHEfile.lhefString(-pdgX[decayBarIndx],partStat,3,0,0,0,pXBar[decayBarIndx].px, pXBar[decayBarIndx].py, pXBar[decayBarIndx].pz, pXBar[decayBarIndx].E, pXBar[decayBarIndx].m0()))
    for i in range(1,xbarDecCount+1):
        outfile.write(pJ2str[i])
        outfile.write(pJ2Barstr[i])
        outfile.write(pXBarstr[i])
    outfile.write('</event>\n')
    #---------------------------------------------------------------------------
outfile.close()
####################################################################
#--------------------- END OF EVENT LOOP ---------------------------
####################################################################

end = time.clock() ##For timing purposes
print nEvents, 'events generated.'
print
print 'GENERATION COMPLETE!'
print
print 'Time for Event Generation: ',(end - start), 's'
print 'Output data stored in:', outfilestr
print

# Output Histograms to Data Files

# Jet number
nJety = histoJetSize
nJetx = range(len(nJety))
fnameString = 'Histo_g' + str(gamma) + '_d' + str(delta) + '_m0' + str(int(m0)) + '_delm' + str(int(delm)) + '_jetNumber.dat'
fileHisto = open(fnameString, 'w')
for i in nJetx:
    # make string for each line we want to write
    txt = str(nJetx[i]) + '\t' + str(nJety[i]) + '\n'
    fileHisto.write(txt)
fileHisto.close()

# Leading jet pT
nJety = histoJetPT
nJetx = range(len(nJety))
fnameString = 'Histo_g' + str(gamma) + '_d' + str(delta) + '_m0' + str(int(m0)) + '_delm' + str(int(delm)) + '_jetPT.dat'
fileHisto = open(fnameString, 'w')
for i in nJetx:
    # make string for each line we want to write
    txt = str(nJetx[i]) + '\t' + str(nJety[i]) + '\n'
    fileHisto.write(txt)
fileHisto.close()


################################################################################
#---------  MAKE SOME HISTOGRAMS  ----------------------------------------------
################################################################################

import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

################ JET NUMBER #######################################################################################
pdfFileStr = 'Histo_JetNumber.pdf'
plt.figure(figsize=(6,4))

xVals_PY = np.arange(nJetBins)
yVals_PY = histoJetSize
PYCol = "#192E3F"
PYbar = plt.hist(xVals_PY, weights = yVals_PY, histtype='stepfilled',bins=99, color = PYCol, alpha = 0.7, label = "Python+Pythia8+Delphes")
# Make the axes
plt.title("Number of Jets")
plt.xlabel("Jets")
plt.ylabel("Events")
plt.xlim(0.0, 20)
plt.xticks(np.arange(0, 20, step=2))

#plt.show()
# Save the plot
fig1 = plt.gcf()
fig1.tight_layout()
fig1.savefig(pdfFileStr, bbox_inches='tight', pad_inches=0.1)
fig1.clear()


################ LEADING JET PT #######################################################################################
pdfFileStr = 'Histo_JetPT.pdf'
plt.figure(figsize=(6,4))

xVals_PY = np.arange(pTBins)
yVals_PY = histoJetPT
pTBins = len(xVals_PY)

PYCol = "#192E3F"
PYbar = plt.hist(xVals_PY, weights = yVals_PY, histtype='stepfilled',bins=(pTBins/20)-1, color = PYCol, alpha = 0.7, label = "Python+Pythia8+Delphes")
# Make the axes
plt.title("Leading Jet $p_T$")
plt.xlabel("$p_T$ (GeV)")
plt.ylabel("Events")
plt.xlim(0.0, 2000)
plt.xticks(np.arange(0, 2000, step=250))

#plt.show()
# Save the plot
fig1 = plt.gcf()
fig1.tight_layout()
fig1.savefig(pdfFileStr, bbox_inches='tight', pad_inches=0.1)
fig1.clear()
