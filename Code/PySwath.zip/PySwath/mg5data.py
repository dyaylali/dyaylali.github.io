def getParticleData(evNum, mPhi, eventsStart):
    MG5fnameString = './PhiProductionData/PhiProduction_mPhi_' + str(int(mPhi)) + '.lhe'
    with open(MG5fnameString) as fp:

        fp.seek(eventsStart + 875*evNum)  #This skips past the header to the events.

        for i, line in enumerate(fp): #Reads lines of event one at a time... stops once it records the PhiMomentum
            # print line
            if i==1:
                evInitLine = line.split()
                evWeight = evInitLine[2]
                evScale = evInitLine[3]
                evQEDScale = evInitLine[4]
                evQCDScale = evInitLine[5]
            if '  9000010' in line:
                # outfile.write(line)
                #print line.strip()
                phiLine = line.split()
                phiColA = phiLine[4]
                phiColB = phiLine[5]
                pPhix = float(phiLine[6])
                pPhiy = float(phiLine[7])
                pPhiz = float(phiLine[8])

            if ' -9000010' in line:
                # outfile.write(line)
                #print line.strip()
                phiLine = line.split()
                phiBarColA = phiLine[4]
                phiBarColB = phiLine[5]
                pPhiBarx = float(phiLine[6])
                pPhiBary = float(phiLine[7])
                pPhiBarz = float(phiLine[8])
                #print pPhiz
                #print
            if i==2:
                glue1Line = line.split()
                glue1pdg = glue1Line[0] # To cover the few cases where incoming quark
                glue1colA = glue1Line[4]
                glue1colB = glue1Line[5]
                glue1Pz = float(glue1Line[8])
            if i==3:
                glue2Line = line.split()
                glue2pdg = glue2Line[0]
                glue2colA = glue2Line[4]
                glue2colB = glue2Line[5]
                glue2Pz = float(glue2Line[8])
            if '</event>' in line:
                break

    phidata = [pPhix, pPhiy, pPhiz, phiColA, phiColB]
    phibardata = [pPhiBarx, pPhiBary, pPhiBarz, phiBarColA, phiBarColB]
    glue1data = [glue1Pz, glue1pdg, glue1colA, glue1colB]
    glue2data = [glue2Pz, glue2pdg, glue2colA, glue2colB]
    eventdata = [evWeight, evScale, evQEDScale, evQCDScale]

    return phidata, phibardata, glue1data, glue2data, eventdata
    # return pPhix, pPhiy, pPhiz, pPhiBarx, pPhiBary, pPhiBarz,evWeight,evScale,evQEDScale,evQCDScale,glue1Pz,glue2Pz,glue1colA,glue1colB,glue2colA,glue2colB,phiColA,phiColB,phibarColA,phibarColB,glue1pdg,glue2pdg
    # return pPhix, pPhiy
