#################### PySwath MC Event Generator ################################

Contact David Yaylali (david.yaylali@gmail.com) with any questions

This program generates events of the form
  p + p > phi + phi~ > X0 + X0~ + N Jets
arising from the DDM model discussed in arXiv:######.  The LHE-format phi-phibar
production data needs to be generated (e.g., in MadGraph5) and placed in the
directory './PhiProductionData/'.  Production events for mPhi=1 TeV are included
by default in this directory for illustrative purposes.

To run, navigate to this (main) directory and do

  $ python PySwath.py

Default run options can be found and adjusted at the beginning of 'PySwath.py'.
After event generation, this program outputs the event data in LHE format, along
with two example histograms (both as .pdf and .dat files).

For more information, see
   www.asthecroworbits.com/computation.html#PySwath
