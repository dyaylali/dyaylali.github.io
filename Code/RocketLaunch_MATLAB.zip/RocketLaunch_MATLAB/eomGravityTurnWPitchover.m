function [dX] = eomGravityTurnWPitchover(t, X, Thr, Isp, m0, d, Cd, tBurn, altPO)
%eomGravityTurnWPitchover Dynamics of a launch vehicle in 2D


    g0 = 9.81;
    Re = 6.378e6;
    muE = 3.986e14;

    r = X(1,1);
    theta = X(2,1);
    v = X(3,1);
    gam = X(4,1);

    % DRAG %
    rho0 = 1.225; %kg/m^3
    h0 = 7500;
    rho = rho0*exp(-(r-Re)/h0);
    A = pi*(d/2)^2;
    D = 0.5*rho*(v^2)*A*Cd;
    %%%%%%%%

    mdot = Thr/(Isp*g0);
    m = m0 - mdot*t;

    if t < tBurn
        m = m0 - mdot*t;     % ...Current vehicle mass
        T = Thr;           % ...Current thrust
    else
        m = m0 - mdot*tBurn; % ...Current vehicle mass
        T = 0;                % ...Current thrust
    end


    g = muE/(r^2);


    if r < Re + altPO
        drdt = v;
        dthetadt =  0;
        dvdt = T/m - D/m - g;
        dgamdt = 0;
    else
        drdt = v*sin(gam);
        dthetadt =  (v/r)*cos(gam);
        dvdt = T/m - D/m - g*sin(gam);
        dgamdt = -(g/v)*cos(gam) + (v/r)*cos(gam);
    end


    dX = [drdt; dthetadt; dvdt; dgamdt];


end
