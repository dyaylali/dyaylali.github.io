function [rvec] = PropOrb_TimeIndep(OE, Np)
%PropOrb_TimeIndep Compute 3D position vector trajectory of orbit
%   USAGE: rvec_t = PropOrb_TimeIndep(OE, Np)
%       INPUT:
%           OE = {6x1 or 1x6 vector of orbital elements [a,e,i,Om,om,f].
%                Angles should be in radians}
%           Np = {Integer > 1.  Number of "time" steps making up the
%                 complete orbit.}
%       OUTPUT:
%           rvec_t = {3x(Np) array of ECI position (column) vectors at each
%                    evaluated value of true anomaly.  Position vectors
%                    correspond to f0=OE(6), f1 = f0 + 2*pi/Np, ...}
%--------------------------------------------------------------------------


    a = OE(1);
    e = OE(2);
    i = OE(3);
    Om = OE(4);
    om = OE(5);
    f0 = OE(6);
    ft = [f0:2*pi/(Np-1):f0+2*pi];

    % Radius
    r = (a*(1-e^2))./(1 + e*cos(ft));
    % Determine the 2D (in-plane) motion of the orbit
    x = r.*cos(ft);
    y = r.*sin(ft);


    %plot(x,y)

    % Add the 3rd dimension...
    rvec_XY = [x; y; zeros(1,length(ft))];

    % Build Orbit Orientation Matrix... note sin(-x)=-sin(x) and cos(-x)=cos(x)
    Zom = [
        +cos(om) -sin(om) 0;
        +sin(om) +cos(om) 0;
        0        0        1
    ];
    Xi = [
        1   0       0;
        0   +cos(i) -sin(i);
        0   +sin(i) +cos(i)
    ];
    ZOm = [
        +cos(Om) -sin(Om) 0;
        +sin(Om) +cos(Om) 0;
        0        0        1
    ];
    OERotMat = ZOm*Xi*Zom;
    % Rotate the vector (at all times) by this matrix:
    rvec = OERotMat*rvec_XY;

end
