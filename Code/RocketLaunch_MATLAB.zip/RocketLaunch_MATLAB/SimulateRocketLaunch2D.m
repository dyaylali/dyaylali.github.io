%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Simulating a Rocket Launch in Two Dimensions
%   This script generates the trajectory of a launch vehicle performing a 
%   standard gravity-turn maneuver, with a specified pitch-over angle and 
%   pitch-over altitude.  This script then plots the trajectory (in terms
%   of radius, declination, velocity magnitude, and flight-path angle), and
%   also plots the resulting orbit.
%
%   Author: David Yaylali (david.yaylali@gmail.com)
%   Last Updated: March 27, 2019
%
%   Depends on the following functions:
%       eomGravityTurnWPitchover.m  --- Dynamics, used for integration
%       PropOrb_TimeIndep.m         --- Simple script to generate 3D
%                                       trajectory from initial OEs
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clearvars
close all
clc

%---- Some constants and run parameters -----------------------------------
d2r = pi/180;
r2d = 180/pi;

Re = 6.378e6;       % Earth radius (m)
muE = 3.986e14;     % Earth gravitational parameter (m^3/s^2)
g0 = muE/(Re^2);    % Gravitational parameter at Earth surface (9.8 m/s^2)

options = odeset('RelTol',1e-10);   % Set integrator precision
%--------------------------------------------------------------------------

%%%% SET ROCKET PARAMETERS AND INITIAL CONDITIONS HERE %%%%%%%%%%%%%%%%%%%%
m0     = 68e3;      % Fueled mass (kg)
n      = 15         % Wet-to-dry mass ratio
mf     = m0/n;      % Dry mass (kg)
T      = 933.0e3;   % Thrust (N)
Isp    = 390;       % Rocket specific impulse (s)
d      = 5;         % Launch vehicle diameter (m)
Cd     = 0.5;       % Drag coefficient

%--- ICs ----
r0 = Re;            % Initial radius at launch (m)
theta0 = 0;         % Initial declination angle at launch 
v0 = 0;             % Initial velocity at launch (m/s)

%--- Trajectory Control Parameters ----
gam0 = 89.82*d2r;   % Initial flight-path angle at pitchover (rad)
altPO = 130;        % Altitude at pitch-over (m)

%--- Initial state for integrator ----
X0 = [r0;theta0;v0;gam0]; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%--- Integrate the trajectory ----

tBurn = ((n-1)/n)*Isp/(T/(m0*g0)) % Total burn time (s)
tArr = [0:0.001:400];   % Integration time-window (adjust as needed)
[~,Xt] = ode45(@(t,y) eomGravityTurnWPitchover(t,y,T,Isp,m0,d,Cd, tBurn, altPO), tArr, X0, options);


%% Plot Trajectory and Orbit

close all
figure('pos',[200,200,1200,350])
set(gcf, 'color', 'w')
sp1 = subplot(1,2,1);
plot(tArr,(Xt(:,1)-Re)*1e-3,'linewidth',1.5)
title('Altitude');
ylabel('$h$ (km)');
xlabel('time (s)');
set(gca, 'FontSize', 14);
box on
grid on
sp2 = subplot(1,2,2);
plot(tArr,Xt(:,3)*1e-3,'linewidth',1.5)
title('Velocity');
ylabel('$|v|$ (km/s)');
xlabel('time (s)');
l1=legend({strcat('$h_{\rm po} =', num2str(altPO),'$ m')});
set(gca, 'FontSize', 14);
box on
grid on
set(sp1, 'Position',[0.06 0.15 0.37 0.75]);
set(sp2, 'Position',[0.5 0.15 0.37 0.75]);
set(l1, 'Position',[0.89 0.67 0.096 0.2229]);

figure('pos',[200,200,1200,350])
set(gcf, 'color', 'w')
sp1 = subplot(1,2,1);
plot(tArr,Xt(:,2)*r2d,'linewidth',1.5)
title('Declination');
ylabel('$\theta$ (deg)');
xlabel('time (s)');
set(gca, 'FontSize', 14);
box on
grid on
sp2 = subplot(1,2,2);
plot(tArr,Xt(:,4)*r2d,'linewidth',1.5)
title('Flight Path Angle');
ylabel('$\gamma$ (deg)');
xlabel('time (s)');
l1=legend({strcat('$h_{\rm po} =', num2str(altPO),'$ m')});
set(gca, 'FontSize', 14);
box on
grid on
set(sp1, 'Position',[0.06 0.15 0.37 0.75]);
set(sp2, 'Position',[0.5 0.15 0.37 0.75]);
set(l1, 'Position',[0.89 0.67 0.096 0.2229]);


%-------- Plot of the resulting orbit ------------------------------------
% Note that we are propagating a single orbit based on the 2D position and 
% velocity at burn out.  Since we are assuming 2D dynamics, we simply set
% inclination manually to zero (so that the third-dimension components are
% zero).  This can be appropriately rotated to the proper orbit if the
% launch azimuth is known.


indBO=find(tArr >= tBurn, 1); % Find time index at burnout
XtBO = Xt(indBO,:)';  % Find launch vehicle state at burnout

%--- set ECI position/velocity (see note above)-------
r0ECI = [XtBO(1);0;0];
v0ECI = [XtBO(3)*sin(XtBO(4)); XtBO(3)*cos(XtBO(4)); 0];

OE0 = rv2koe(r0ECI,v0ECI,muE,'deg'); % Compute orbital elements
a = OE0(1);
e = OE0(2);
f = OE0(6);
fprintf('\n Semimajor Axis: %d \n', a)
fprintf('\n Eccentricity: %d \n', e)
fprintf('\n True Anomaly: %d \n', f)

%--- Propagate orbit (with no time dependence) for purposes of plotting
rofT = PropOrb_TimeIndep(OE0,1000);

%--- Visualize the orbit from the North Pole
figure()
set(gcf, 'color', 'w')
[ex,ey,ez] = sphere(50);
hold on
surf(ex*Re.*1e-3,ey*Re.*1e-3,ez*Re.*1e-3)
plot3(rofT(1,:).*1e-3,rofT(2,:).*1e-3,rofT(3,:).*1e-3,'linewidth',1.5)
hold off
axis equal
view([0 90])
set(gca,'visible','off')