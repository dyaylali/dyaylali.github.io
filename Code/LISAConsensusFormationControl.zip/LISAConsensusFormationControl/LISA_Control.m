% Consensus Control to Build the LISA Formation 
% David Yaylali (david.yaylali@gmail.com)
% November, 2018
%
% This script illustrates the use of virtual leader-follower consensus
% control laws to build a circular relative-orbit configuration of three
% spacecraft.  As an application of such a control protocol, we build the
% LISA triangular constellation, which we assume to be launched as a
% bundled package of three spacecraft to a single location in an
% Earth-trailing heliocentric orbit.  Since the final inter-SC distance is
% about 100 times smaller than the heliocentric orbit radius, the
% linearized HCW dynamics should approximately hold.

clearvars
close all
clc
%addpath ./functions %<--No external functions needed for this script

% Set integrator options:
tol = 3e-14;
options = odeset('RelTol',tol,'AbsTol',tol);
d2r = pi/180;
r2d = 180/pi;

% Define colors for different SC (using the linspecer package)
c1 = [0.368  0.309  0.635];
c2 = [0.200  0.559  0.738];
c3 = [0.455  0.789  0.645];

%  Set parameters
muS = 1.32712440018e20*1e-9;
AU = 149597870.700; % km
aE = 149598023; % km

ac = aE;
nc = sqrt(muS/(ac^3));
Torb = 2*pi*sqrt((ac)^3 / muS);

%------------ SETUP ICS ------------------------------------------------

%Constellation geometry
aSep = 2.5e6; %needed separation
rRel = aSep*sind(30)/sind(120); % From law of sines


%----- ICs of the actual (follower) SCs in LVLH frame ---------------------
% These are simply at the origin of the LVLH frame
X1 = [0 0 0 0 0 0]';
X2 = [0 0 0 0 0 0]';
X3 = [0 0 0 0 0 0]';


%----- Set up ICs of virtual nodes along the circular relative orbit ------
% These are found from the general solutions of the HCW equations
t0 = 0;
A0 = rRel/2;
B0 = sqrt(3)*A0; % solution for circular relative-orbit
% Virtual node for SC1
alpha = 0; beta = alpha;
x0 = A0*cos(nc*t0 + alpha); 
y0 = -2*A0*sin(nc*t0 + alpha);
z0 = B0*cos(nc*t0 + beta);
xdot0 = -A0*nc*sin(nc*t0 + alpha);
ydot0 = -2*A0*nc*cos(nc*t0 + alpha);
zdot0 = -B0*nc*sin(nc*t0 + beta);
X1v = [x0; y0; z0; xdot0; ydot0; zdot0];
% Virtual node for SC2
phi2 = 2*pi/3; % phase separation
x0 = A0*cos(nc*t0 + alpha + phi2);
y0 = -2*A0*sin(nc*t0 + alpha + phi2);
z0 = B0*cos(nc*t0 + beta + phi2);
xdot0 = -A0*nc*sin(nc*t0 + alpha + phi2);
ydot0 = -2*A0*nc*cos(nc*t0 + alpha + phi2);
zdot0 = -B0*nc*sin(nc*t0 + beta + phi2);
X2v = [x0; y0; z0; xdot0; ydot0; zdot0];
% Virtual node for SC3
phi3 = 2*2*pi/3; % phase separation
x0 = A0*cos(nc*t0 + alpha + phi3);
y0 = -2*A0*sin(nc*t0 + alpha + phi3);
z0 = B0*cos(nc*t0 + beta + phi3);
xdot0 = -A0*nc*sin(nc*t0 + alpha + phi3);
ydot0 = -2*A0*nc*cos(nc*t0 + alpha + phi3);
zdot0 = -B0*nc*sin(nc*t0 + beta + phi3);
X3v = [x0; y0; z0; xdot0; ydot0; zdot0];
% Clean up some variables
clear x0 y0 z0 xdot0 ydot0 zdot0 t0 alpha beta phi2 phi3

%----- Define HCW System --------------------------------------------------
A1 = [3*nc^2 0 0 ; 0 0 0; 0 0 -nc^2];
A2 = [0 2*nc 0; -2*nc 0 0; 0 0 0];
AHCW = [zeros(3) eye(3); A1 A2];
B = [zeros(3); eye(3)];

%----- Find LQR Control ---------------------------------------------------
% adjust Q and R so that formation is achieved in reasonable amount of time
Q=[10*eye(3),zeros(3,3); zeros(3,3), (1/nc^2)*eye(3)];
R=(10/nc^4)*eye(3);
[KLQR,~,~]=lqr(AHCW,B,Q,R);

%----- Define Leader follower topology and cooperative EOM ----------------
L = [0 0; -1 1];
N = length(L);
IN = eye(N);
% Closed-loop coop control matrix
ACL = kron(IN,AHCW)-kron(L,B*KLQR);

%----- define the leader-follower states (local rep) ----------------------
Z10 = [X1v; X1];
Z20 = [X2v; X2];
Z30 = [X3v; X3];

%----- INTEGRATE COOPERATIVE CONTROL HCW EQUATIONS ------------------------
tArray = [1:1e4:6*Torb];
% Integrate SC1 virtual leader-follower pair trajectory
[~,Z1t] = ode45(@(t,y) ACL*y,tArray,Z10,options);
Z1t = Z1t';
r1v = Z1t(1:3,:);
v1v = Z1t(4:6,:);
r1 = Z1t(7:9,:);
v1 = Z1t(10:12,:);
% Integrate SC2 virtual leader-follower pair trajectory
[~,Z2t] = ode45(@(t,y) ACL*y,tArray,Z20,options);
Z2t = Z2t';
r2v = Z2t(1:3,:);
v2v = Z2t(4:6,:);
r2 = Z2t(7:9,:);
v2 = Z2t(10:12,:);
% Integrate SC2 virtual leader-follower pair trajectory
[~,Z3t] = ode45(@(t,y) ACL*y,tArray,Z30,options);
Z3t = Z3t';
r3v = Z3t(1:3,:);
v3v = Z3t(4:6,:);
r3 = Z3t(7:9,:);
v3 = Z3t(10:12,:);


%% PLOT TRAJECTORY OF SC1 DURING FORMATION MANEUVER

%----- PLOT ORBIT FOR SC1 (PHYSICAL + VIRTUAL) ----------------------------
% find time index corresponding to a single orbit
indTorb = find(abs(tArray-Torb)<10000,1);

figure('Position',[200,200, 500, 500])
hold on
plot3(r1v(1,1:indTorb).*1e-6,r1v(2,1:indTorb).*1e-6,r1v(3,1:indTorb).*1e-6,'--','color',c1,'LineWidth',1.5)
plot3(r1(1,:).*1e-6,r1(2,:).*1e-6,r1(3,:).*1e-6,'color',c1)
hold off
axis equal
grid on
title('Trajectory (SC1)')
set(gca, 'FontSize', 14);
xlabel('$x$ ($\times 10^6$ km)', 'FontSize', 18)
ylabel('$y$ ($\times 10^6$ km)', 'FontSize', 18)
zlabel('$z$ ($\times 10^6$ km)', 'FontSize', 18)
view([-60,25])

%----- PLOT EVOLUTION OF ORBIT FOR SC! (PHYSICAL + VIRTUAL ORBITS) --------
it1= 2500;
it2= 5000;
it3= 10000;
dt = 20;

fig2 = figure('Position',[200,200, 1500, 550]);
lmarg = 0.05;
wsFig = (1-(3*lmarg))/3;
wFig = wsFig+lmarg;
pos1 = [lmarg 0.15 0.25 0.75];
pos2 = [(wFig+lmarg) 0.15 0.25 0.75];
pos3 = [(2*wFig+lmarg) 0.15 0.25 0.75];

subplot('position',pos1)
hold on
plot3(r1(1,1:it1).*1e-6,r1(2,1:it1).*1e-6,r1(3,1:it1).*1e-6,'color',c1,'LineWidth',1.5);
plot3(r1v(1,1:dt:it1).*1e-6,r1v(2,1:dt:it1).*1e-6,r1v(3,1:dt:it1).*1e-6,'o','color',c1,'MarkerSize',0.7);
hold off
axis([-5 5 -1.5 1.5 -1.2 1.2]);
ax = gca;               % get the current axis
ax.Clipping = 'off';    % turn clipping off
set(gca, 'FontSize', 14);
xlab = xlabel('$x$', 'FontSize', 18);
ylab = ylabel('$y$', 'FontSize', 18);
zlab = zlabel('$z$', 'FontSize', 18);
set(xlab, 'Position', get(xlab,'position')+[0.5,-0.2,0.4], 'Rotation', 0);
set(ylab, 'Position', get(ylab,'position')+[0,0.3,0.2], 'Rotation', 0);
set(zlab, 'Position', get(zlab,'position')+[0.1,0.0,0.0], 'Rotation', 0);
view([-75, 20]);
grid on;
box on;

t1 = tArray(it1)/Torb;
txt1 = strcat('$T/T_{\rm orb} = ',num2str(t1,2),'$');
text(0.25,0.93,txt1,'Units','normalized','interpreter','latex','FontSize',16);

subplot('position',pos2)
hold on
plot3(r1(1,1:it2).*1e-6,r1(2,1:it2).*1e-6,r1(3,1:it2).*1e-6,'color',c1,'LineWidth',1.5);
plot3(r1v(1,1:dt:indTorb).*1e-6,r1v(2,1:dt:indTorb).*1e-6,r1v(3,1:dt:indTorb).*1e-6,'o','color',c1,'MarkerSize',0.7);
hold off
axis([-5 5 -1.5 1.5 -1.2 1.2]);
ax = gca;               % get the current axis
ax.Clipping = 'off';    % turn clipping off
set(gca, 'FontSize', 14);
xlab = xlabel('$x$', 'FontSize', 18);
ylab = ylabel('$y$', 'FontSize', 18);
zlab = zlabel('$z$', 'FontSize', 18);
set(xlab, 'Position', get(xlab,'position')+[0.5,-0.2,0.4], 'Rotation', 0);
set(ylab, 'Position', get(ylab,'position')+[0,0.3,0.2], 'Rotation', 0);
set(zlab, 'Position', get(zlab,'position')+[0.1,0.0,0.0], 'Rotation', 0);
view([-75, 20]);
grid on;
box on;

t1 = tArray(it2)/Torb;
txt1 = strcat('$T/T_{\rm orb} = ',num2str(t1,2),'$');
text(0.25,0.93,txt1,'Units','normalized','interpreter','latex','FontSize',16);
txtTitle = 'Evolution of the Trajectory (SC1)';
text(0.1,1.05,txtTitle,'Units','Normalized','interpreter','latex','FontSize',20);

subplot('position',pos3);
hold on
plot3(r1(1,1:it3).*1e-6,r1(2,1:it3).*1e-6,r1(3,1:it3).*1e-6,'color',c1,'LineWidth',1.5);
plot3(r1v(1,1:dt:indTorb).*1e-6,r1v(2,1:dt:indTorb).*1e-6,r1v(3,1:dt:indTorb).*1e-6,'o','color',c1,'MarkerSize',0.7);
hold off
axis([-5 5 -1.5 1.5 -1.2 1.2]);
ax = gca;               % get the current axis
ax.Clipping = 'off';    % turn clipping off
set(gca, 'FontSize', 14);
xlab = xlabel('$x$', 'FontSize', 18);
ylab = ylabel('$y$', 'FontSize', 18);
zlab = zlabel('$z$', 'FontSize', 18);
set(xlab, 'Position', get(xlab,'position')+[0.5,-0.2,0.4], 'Rotation', 0);
set(ylab, 'Position', get(ylab,'position')+[0,0.3,0.2], 'Rotation', 0);
set(zlab, 'Position', get(zlab,'position')+[0.1,0.0,0.0], 'Rotation', 0);
view([-75, 20]);
grid on;
box on;
t1 = tArray(it3)/Torb;
txt1 = strcat('$T/T_{\rm orb} = ',num2str(t1,2),'$');
text(0.25,0.93,txt1,'Units','normalized','interpreter','latex','FontSize',16);


%% PLOT TRAJECTORY OF THE ENTIRE FORMATION

figure('Position',[200,200, 1400, 500])
%----Positioning Commands-----------
% number of subfigs:
Nsfig = 2;
lbwh = get(gcf, 'position');
figW = lbwh(3);
figH = lbwh(4);
sfigW = (figW/Nsfig)*0.98; %
lmargW = sfigW*0.13; % left subfig margin
spltW = sfigW*0.87; % subplot width
lowmarg = 0.15; % lower margin
l1 = lmargW/figW;
l2 = (lmargW+sfigW)/figW;
%l3 = (lmargW+2*sfigW)/figW
%pos1 = [l1 lowmarg spltW/figW 0.8];
pos1 = [0.06 0.15 0.35 0.8];
pos2 = [l2 lowmarg spltW/figW 0.8];
%-----------------------------------

subplot('Position',pos1)
%subplot(1,2,1)
hold on
plot(r1(2,:).*1e-6,r1(3,:).*1e-6,'Color',c1,'linewidth',1.2)
plot(r2(2,:).*1e-6,r2(3,:).*1e-6,'Color',c2,'linewidth',1.2)
plot(r3(2,:).*1e-6,r3(3,:).*1e-6,'Color',c3,'linewidth',1.2)
plot(r1(2,end).*1e-6,r1(3,end).*1e-6,'o','MarkerFaceColor','k')
plot(r2(2,end).*1e-6,r2(3,end).*1e-6,'o','MarkerFaceColor','k')
plot(r3(2,end).*1e-6,r3(3,end).*1e-6,'o','MarkerFaceColor','k')
hold off
axis([-2 2 -1.5 1.5])
%axis equal
grid on
box on
ax = gca;               % get the current axis
ax.Clipping = 'off';    % turn clipping off
set(gca, 'FontSize', 14);
xlabel('$y$ ($\times 10^6$ km)', 'FontSize', 18)
ylabel('$z$ ($\times 10^6$ km)', 'FontSize', 18)

subplot('Position',pos2)
hold on
plot3(r1(1,:),r1(2,:),r1(3,:),'Color',c1,'linewidth',1.2)
plot3(r2(1,:),r2(2,:),r2(3,:),'Color',c2,'linewidth',1.2)
plot3(r3(1,:),r3(2,:),r3(3,:),'Color',c3,'linewidth',1.2)
plot3(r1(1,end),r1(2,end),r1(3,end),'o','MarkerFaceColor','k')
plot3(r2(1,end),r2(2,end),r2(3,end),'o','MarkerFaceColor','k')
plot3(r3(1,end),r3(2,end),r3(3,end),'o','MarkerFaceColor','k')
hold off
axis equal
ax = gca;               % get the current axis
ax.Clipping = 'off';    % turn clipping off
set(gca, 'FontSize', 14);
xlabel('$x$', 'FontSize', 18)
ylabel('$y$', 'FontSize', 18)
zlabel('$z$', 'FontSize', 18)
view([-11,10])
grid on
box on

%% ANIMATE THE FORMATION MANEUVER

% Write animation to video file?
vidFileFlag = 0;
vidFileStr = 'LISAConsensusFormationAnimation.avi';

%h = figure('Position',[680 549 400 360]) 
h = figure('Position',[2000 549 400 360]) 
set(gcf, 'color', 'w')
hold on
dep1=plot3(r1(1,1).*1e-6,r1(2,1).*1e-6,r1(3,1).*1e-6,'o','Color',c1,'linewidth',1.2,'MarkerFaceColor',c1,'MarkerSize',10)
dep2=plot3(r1(1,1).*1e-6,r1(2,1).*1e-6,r1(3,1).*1e-6,'o','Color',c2,'linewidth',1.2,'MarkerFaceColor',c2,'MarkerSize',10)
dep3=plot3(r1(1,1).*1e-6,r1(2,1).*1e-6,r1(3,1).*1e-6,'o','Color',c3,'linewidth',1.2,'MarkerFaceColor',c3,'MarkerSize',10)
hold off

view([-60 20])
xlabel('$ x$ ($\times 10^6$ km)','Position',[-0.54915  -2.3  -1.5], 'rotation', 35)
ylabel('$y$ ($\times 10^6$ km)','Position',[-2.1  -0.5  -1.5])
zlab = zlabel('$z$ ($\times 10^6$ km)', 'rotation', 90)
axis equal
% box on
xlim([-1.2 1.2])
ylim([-1.5 1.5])
zlim([-1.5 1.5])
grid on
pltArea = gca
set(pltArea,'Position',[0.04 0.1 1 0.9])

pause

if vidFileFlag
    animation = VideoWriter(vidFileStr);
    animation.FrameRate = 40;       
    open(animation);
end

for k = 1:20:5000
    hold on
    plot3(r1(1,1:k).*1e-6,r1(2,1:k).*1e-6,r1(3,1:k).*1e-6,'Color',c1,'linewidth',1.0)
    plot3(r2(1,1:k).*1e-6,r2(2,1:k).*1e-6,r2(3,1:k).*1e-6,'Color',c2,'linewidth',1.0)
    plot3(r3(1,1:k).*1e-6,r3(2,1:k).*1e-6,r3(3,1:k).*1e-6,'Color',c3,'linewidth',1.0)
    hold off
    set(dep1, 'xdata', r1(1,k).*1e-6, 'ydata', r1(2,k).*1e-6, 'zdata', r1(3,k).*1e-6)
    set(dep2, 'xdata', r2(1,k).*1e-6, 'ydata', r2(2,k).*1e-6, 'zdata', r2(3,k).*1e-6)
    set(dep3, 'xdata', r3(1,k).*1e-6, 'ydata', r3(2,k).*1e-6, 'zdata', r3(3,k).*1e-6)
    drawnow
    if vidFileFlag
        writeVideo(animation, getframe(gcf));
    end
end
if vidFileFlag
    close(animation);
end

%% PLOT LVLH POSITION MAGNITUDES AND INTER-SC DISTANCES AS FUNCTION OF TIME
% If the maneuver was succesful, the relative orbits should be circular
% (|r|-> constant), and the interspacecraft distance should become
% constant.

close all
rmag1 = vecnorm(r1);
rmag2 = vecnorm(r2);
rmag3 = vecnorm(r3);

figure('Position',[2000,200, 1300, 400])
set(gcf, 'color', 'w')

subplot('Position',[0.06 0.14 0.42 0.75])
hold on
plot(tArray./Torb, rmag1.*1e-6,'linewidth',1.5,'color',c1)
plot(tArray./Torb, rmag2.*1e-6,'linewidth',1.5,'color',c2)
plot(tArray./Torb, rmag3.*1e-6,'linewidth',1.5,'color',c3)
hold off
axis([0 3 0 1.75])
title('Magnitude of LVLH Position Vector')
set(gca, 'FontSize', 14);
xlabel('$t/T_{\rm orb}$', 'FontSize', 18)
ylabel('$|\vec{r}|$ ($\times 10^6$ km)', 'FontSize', 18)
print('-clipboard','-dbitmap')
grid on
box on
legend({'$|${\boldmath$\rho$}${}_{1}|$','$|${\boldmath$\rho$}${}_{2}|$', '$|${\boldmath$\rho$}${}_{3}|$'},'fontsize',18,'position',[0.37,0.23,0.1,0.1])
% export_fig('../../figures/Chapter3Figs/LISAControl_RadialDistance_C3.pdf','-transparent')

delta12 = vecnorm(r1-r2);
delta13 = vecnorm(r1-r3);
delta23 = vecnorm(r2-r3);
subplot('Position',[0.56 0.14 0.42 0.75])
hold on
plot(tArray./Torb, delta12.*1e-6,'linewidth',1.5,'color',c1)
plot(tArray./Torb, delta13.*1e-6,'linewidth',1.5,'color',c2)
plot(tArray./Torb, delta23.*1e-6,'linewidth',1.5,'color',c3)
hold off
axis([0 3 0 3])
title('Relative Inter-Deputy Distance')
set(gca, 'FontSize', 14);
xlabel('$t/T_{\rm orb}$', 'FontSize', 18)
ylabel('$|\Delta {r_{ij}}|$ ($\times 10^6$ km)', 'FontSize', 18)
print('-clipboard','-dbitmap')
grid on
box on
legend({'$\Delta r_{12}$','$\Delta r_{13}$', '$\Delta r_{23}$'},'fontsize',18,'position',[0.86,0.23,0.1,0.1])

%export_fig('LISAManeuverGeometry.jpg', '-nocrop', '-m0.85')