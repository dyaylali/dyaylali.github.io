function animate_rigid_body(R, dt)
%animate_rigid_body Animate the rigid body motion. 
% Taken and modified from Daniel Kawano, Rose-Hulman Institute of Technology


%OUTPUT VIDEO FILE?
outVidFlag = 0;
vidFileStr = 'RigidBodyTumblingExample.avi';

%  Specify dimensions for the T-handle:

LAG = 0.5;        %  cm
LBC = 1.5;        %  cm
LAD = 1.5;        %  cm

figure
set(gcf, 'color', 'w')
plot3(0, 0, 0);
view(120,20)
xlabel('$X$ (cm)')
%set(gca, 'xdir', 'reverse')
ylabel('$Y$ (cm)')
%set(gca, 'ydir', 'reverse')
zlabel('$Z$ (cm)', 'rotation', 0)

axis equal
xlim(LBC*[-1, 1]);
ylim(LBC*[-1, 1]);
zlim(LAD*[-1, 1]);
grid on


for k = 1:length(R)
    e1(:,k) = R(:,:,k)*[1; 0; 0];              %  e1
    e2(:,k) = R(:,:,k)*[0; 1; 0];              %  e2
    e3(:,k) = R(:,:,k)*[0; 0; 1];              %  e3
end


e1Line = line('xdata', [0, e1(1,1)], 'ydata', [0, e1(2,1)], 'zdata', [0, e1(3,1)], 'color', 'k', 'linewidth', 3);
e2Line = line('xdata', [0, e2(1,1)], 'ydata', [0, e2(2,1)], 'zdata', [0, e2(3,1)], 'color', 'r', 'linewidth', 3);
e3Line = line('xdata', [0, e3(1,1)], 'ydata', [0, e3(2,1)], 'zdata', [0, e3(3,1)], 'color', 'b', 'linewidth', 3);

pause

if outVidFlag
    animation = VideoWriter(vidFileStr);
    animation.FrameRate = 1/dt;       
    open(animation);
end

for k = 1:length(R)
    set(e1Line, 'xdata', [0, e1(1,k)], 'ydata', [0, e1(2,k)], 'zdata', [0, e1(3,k)]);
    set(e2Line, 'xdata', [0, e2(1,k)], 'ydata', [0, e2(2,k)], 'zdata', [0, e2(3,k)]);
    set(e3Line, 'xdata', [0, e3(1,k)], 'ydata', [0, e3(2,k)], 'zdata', [0, e3(3,k)]);

    drawnow
    if outVidFlag
        writeVideo(animation, getframe(gcf));
    end
end