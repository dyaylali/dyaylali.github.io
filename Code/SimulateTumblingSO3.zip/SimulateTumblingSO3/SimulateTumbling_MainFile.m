% Simulate Rigid Body Tumbling --- David Yaylali
% Last Modified, November 2016
%
% This code simulates the motion of a tumbling rigid body in the formalism
% of the rotation group SO(3).  The state of the body at any time is
% represented by the SO(3) lie group members R, which are the direction
% cosine matrices.
%
% A rectangular box, such as a book or a cell phone, thrown in the air
% can tumble stably about its longest axis, or about its shortest axis, 
% but not about its middle axis.  This will be illustrated here by defining
% a body with principle moment of inertia tensor J = diag([a,b,c]), with
% a<b<c.

% Initialize
clearvars
clc
close all
r2d = 180.0/pi;
d2r = 1/r2d;
% Use LaTeX (comment out and relabel axis if latex not available)
set(0,'defaultTextInterpreter','latex');
set(groot, 'defaultLegendInterpreter','latex');

%% Define orientation in terms of direction cosine matrix, along with angular velocity

%Mass and rotational inertia of body
m = 1; 
J = diag([0.2*m 0.3*m 0.4*m]);


%Initial orientation (euler angles, ZXZ convention)
thetZ0 = 0;
thetX = pi/2;
thetZ1 = 0;

% Initial rotation matrix corresponding to these angles
R = rotMatEA( thetZ0, thetX, thetZ1 );
%Initial rotational velocity
om = [0.1;15;0.1]; %Set small non-zero components in the x- and z- directions to illustrate instability.


%% Simulating Tumbling of Bodies

% Setup initial dynamics
RDot = R*CrossOp(om);
omDot = J\(-CrossOp(om)*J*om);

% Flatten all matrices in order to integrate in ode45
R0 = R(:);
om0 = om(:);
F0 = [R0; om0];

% Setup integration parameters
tf = 5;                        
dt = 0.01;                     
tsim = [0 : dt : tf]';          
tol = 1e-6; 

% Integrate (using external function matDeriv which contains the dynamics)
options = odeset('abstol', tol, 'reltol', tol);
[T,F] = ode45(@(t,y) matDerivSO3(t,y,J), tsim, F0(:));

% Assign R and omega as a function of time to arrays
RofT=zeros(3,3,length(T));
omofT=zeros(3,1,length(T));
for i = 1:length(T)
   RofT(1:3,1,i) = F(i,1:3)';
   RofT(1:3,2,i) = F(i,4:6)';
   RofT(1:3,3,i) = F(i,7:9)';
   omofT(1:3,i) = F(i,10:12)';
end

%% Compute and plot components of angular momentum versus time

L1 = J(1,1)*omofT(1,:);                       
L2 = J(2,2)*omofT(2,:);                        
L3 = J(3,3)*omofT(3,:);                        
Lnorm = sqrt(L1.^2 + L2.^2 + L3.^2);            

figure
plot(T, L1, T, L2, T, L3, T, Lnorm, 'linewidth', 2)
xlabel('Time (s)')
ylabel('Angular momentum')
legend('$L_x$', ...
       '$L_y$', ...
       '$L_z$', ...
       '$|\bf{L}|$')

%% Animate!
animate_rigid_body(RofT, dt)


%% Integration Error
% We are using ode45 which inevatably leads to integration error.  This can
% be seen by comparing R^(T)R as a function of time to the identity matrix.
% Since rotation matrices R are orthogonal matrices, these R^(T)R *should*
% strictly be equal to the identity.

for n = 1:length(T)
   divergR(n) = norm(RofT(:,:,n)*RofT(:,:,n)'-eye(3));
end

figure
plot(T,divergR)
title('$|R^T R - I|$','interpreter','latex')
xlabel('Time')

% To mitigate this error, one should use a "geometric integrator".  