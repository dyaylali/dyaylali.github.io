function rotMat = rotMatEA( Z0, X, Z1 )
%rotMatEA Rotation matrix A from Euler angles -- zyz convention


   rotMat = [
   cos(Z0)*cos(Z1)-sin(Z0)*cos(X)*sin(Z1)  -cos(Z0)*sin(Z1)-sin(Z0)*cos(X)*cos(Z1)  sin(Z0)*sin(X);
   sin(Z0)*cos(Z1)+cos(Z0)*cos(X)*sin(Z1)  -sin(Z0)*sin(Z1)+cos(Z0)*cos(X)*cos(Z1) -cos(Z0)*sin(X);
   sin(X)*sin(Z1)                                sin(X)*cos(Z1)                               cos(X)
   ];


end
