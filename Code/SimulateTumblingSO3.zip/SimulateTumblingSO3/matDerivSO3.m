function dy = matDerivSO3( t,y,J )
%matDerivSO3 Compute the right-hand side of the dynamical equation for
%rigid body motion in SO(3), for use in numerical integration.

   %Reshape y into matrix and vector R and om
   R = reshape(y(1:9),3,3);
   om = reshape(y(10:12),3,1);

   %Compute evolution
   Rdot = R*CrossOp(om);
   omdot = J\(-CrossOp(om)*J*om);

   %Reshape back into vector
   Rdotvec = Rdot(:);
   omdotvec = omdot(:);
   dy = [Rdotvec; omdotvec];

end

