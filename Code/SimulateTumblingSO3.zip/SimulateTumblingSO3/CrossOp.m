function CPmatrix = CrossOp( x )
%CrossOp Compute cross-product tensor of a vector

if ~isvector(x)
    error('Input must be a vector')
end
CPmatrix = [0 -x(3,1) x(2,1) ;
    x(3,1) 0 -x(1,1);
    -x(2,1) x(1,1) 0];
end

